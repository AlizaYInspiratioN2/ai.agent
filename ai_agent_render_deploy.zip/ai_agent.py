import os
from flask import Flask, request, render_template_string
import openai
from dotenv import load_dotenv

load_dotenv()
openai.api_key = os.getenv("OPENAI_API_KEY")

app = Flask(__name__)

HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>AI Agent</title>
</head>
<body>
    <h1>Ask the AI Agent</h1>
    <form method="post">
        <textarea name="prompt" rows="4" cols="60" placeholder="Ask me anything...">{{ prompt or '' }}</textarea><br>
        <button type="submit">Submit</button>
    </form>
    {% if response %}
    <h2>Response:</h2>
    <pre>{{ response }}</pre>
    {% endif %}
</body>
</html>
"""

@app.route("/", methods=["GET", "POST"])
def index():
    response = ""
    prompt = ""
    if request.method == "POST":
        prompt = request.form.get("prompt")
        try:
            completion = openai.ChatCompletion.create(
                model="gpt-4o",
                messages=[{"role": "user", "content": prompt}]
            )
            response = completion['choices'][0]['message']['content']
        except Exception as e:
            response = f"❌ Error: {e}"
    return render_template_string(HTML_TEMPLATE, response=response, prompt=prompt)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)