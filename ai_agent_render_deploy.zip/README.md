# AI Coding Agent (GPT-4o + Flask)

This is a simple AI agent using OpenAI's GPT-4o model, deployable on Render for free.

## 🟢 One Click Deploy (to Render)

[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://render.com/deploy)

## 🔧 Setup (Local)

1. Clone the repo
2. Create a `.env` file:

```
OPENAI_API_KEY=sk-proj-your-key-here
```

3. Run it:

```bash
pip install -r requirements.txt
python ai_agent.py
```

Visit `http://localhost:5000` in your browser.